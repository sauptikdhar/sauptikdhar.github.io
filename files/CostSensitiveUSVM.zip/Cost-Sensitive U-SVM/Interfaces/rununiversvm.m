function [Rpred,Remp,model,output] =rununiversvm(type,trainfile,testfile,univfile,param,dim)
%--------------------------------------------------------------------------
%AUTHOR:- SAUPTIK DHAR
%DESCRIPTION:-
%  [Rpred,Remp,model]=rununiversvm(type,trndata,tstdata,isFile,param,modelfile)
% This interface will be used to run the universum algorithm for the
% specified parameters.
%INPUT:-
%  type:- This specifies the type of SVM used.
%        1=Non Standard SVM  
%        2= Non Standard U-SVM
%  trainfile:- This is the file name containing the Training data.This file
%  is created using the interface writeFile(data,filename).
%
%  tstdata:- This is the file containing the Test data
%  univdata:- This is the filename containing the Universum samples.
%
%  param: This is the structure which specifies the list of parameters to
%   be used to run the universum.The specified fields are
%       param.c= This is the C parameter for the SVM
%       param.t= This specifies the type of kernel function.
%       param.d= This will specify the degree of the polynomial Kernel.
%       param.g= This will specify the radius of the kernel(Radial Basis).
%       param.k= This is the ratio of Cfp/Cfn(used for training the model).
%       This parameter need not be specified for SVM and Universum SVM.
%       param.K= This is the ratio of Cfp/Cfn(used to claculate the
%       accuracy).This parameter need not be specified for SVM and Universum SVM.
%       param.modify= This will specify if we modify the Universum costs.
%  
%  dim:- This is the dimension of the feature space.
%  
%OUTPUT:-
%  Rpred:- This is the Prediction Risk of the trained model on the test
%  data.
%
%  Remp:- This is the classification error(Emperical risk)on the training
%  data.
%
%  model:- This is the modelfile.This contains the following fields.
%       model.alpha= The alpha value of the SVM model.
%       model.b= The bias of the SVM model.
%       model.sv.X= the X values of the support vectors.
%       model.nsv= The number of support vectors.
%       model.modelfile=The modelfile where the model is stored!
%  output:- This is the output which contains the projection values for the  
%
%Note: For the interface we atleast need to specify the first 4
%parameters.Moreover to run the interface the current directory should be
%the folder with the universvm.exe
%--------------------------------------------------------------------------

%INITIALIZE
Rpred=nan;
Remp=nan;



% LOAD DATA.(It is assumed that the trndata contains the universum samples)

    modelfile='Model.mdl';
    outputtrain='OutputTrain.out';
    outputtest='OutputTest.out';
    [success]=createFile(modelfile);
    [success]=createFile(outputtrain);
    [success]=createFile(outputtest);

% CALL APPROPRIATE INTERFACE
switch(type)
    case 1,       
            [Rpred,Remp,model] =runNSTDsvm(trainfile,testfile,param,modelfile,outputtrain,outputtest,dim);
    case 2,  
            [Rpred,Remp,model] =runNSTDUsvm(trainfile,testfile,univfile,param,modelfile,outputtrain,outputtest,dim);
    otherwise, error('Please specify the appropriate problem type!');
end
model.modelfile=modelfile;
output.train.projection = outputfileread(outputtrain);
output.test.projection= outputfileread(outputtest);








% function [Rpred,Remp,model] =runsvm(trainfile,testfile,param,modelfile,outputtrain,outputtest,dim)
% %--------------------------------------------------------------------------
% % This part of the program will be called internally
% % In this case the number of parameters that need to be specified are:-
% % param.c= This is the C parameter for the SVM
% % param.t= This specifies the type of kernel function.
% % param.d= This will specify the degree of the polynomial Kernel.
% % param.g= This will specify the radius of the kernel(Radial Basis).
% % Call Universum as:-
% %   universvm [options] trainfile modelfile
% %   universvm [options] -F model testfile
% %--------------------------------------------------------------------------
% 
% switch(param.t)
%     case 'linear',
%     [a,tstOut] = system(['universvm',' -c ',num2str(param.c),' -T ',testfile,' -D ',outputtest,' ',trainfile,' ',modelfile]);
%     [a,trnOut]= system(['universvm',' -D ',outputtrain,' -F ',modelfile,' ',trainfile]);
%     [Rpred,Remp,model]= readOutputStr(tstOut,trnOut,modelfile,dim);
%     
%     case 'rbf',
%     [a,tstOut] = system(['universvm',' -c ',num2str(param.c),' -t ',num2str(2),' -g ',num2str(param.g),' -T ',testfile,' -D ',outputtest,' ',trainfile,' ',modelfile]);
%     [a,trnOut]= system(['universvm',' -D ',outputtrain,' -F ',modelfile,' ',trainfile]);
%     [Rpred,Remp,model]= readOutputStr(tstOut,trnOut,modelfile,dim);
%     
%     case 'poly',
%     [a,tstOut] = system(['universvm',' -c ',num2str(param.c),' -t ',num2str(1),' -d ',num2str(param.d),' -r ',num2str(1),' -T ',testfile,' -D ',outputtest,' ',trainfile,' ',modelfile]);
%     [a,trnOut]= system(['universvm',' -D ',outputtrain,' -F ',modelfile,' ',trainfile]);
%     [Rpred,Remp,model]= readOutputStr(tstOut,trnOut,modelfile,dim);
%     
%     otherwise,error('This type of Kernel is not supported');
% end




function [Rpred,Remp,model] =runNSTDsvm(trainfile,testfile,param,modelfile,outputtrain,outputtest,dim)
%--------------------------------------------------------------------------
% This part of the program will be called internally
% In this case the number of parameters that need to be specified are:-
% param.c= This is the C parameter for the SVM
% param.t= This specifies the type of kernel function.
% param.d= This will specify the degree of the polynomial Kernel.
% param.g= This will specify the radius of the kernel(Radial Basis).
% param.k= This is the ration of Cfp/Cfn (for training)
% Call Universum as:-
%   universvm [options] trainfile modelfile
%   universvm [options] -F model testfile
%--------------------------------------------------------------------------

switch(param.t)
    case 'linear',
    [a,tstOut] = system(['universvm',' -c ',num2str(param.c),' -k ',num2str(param.k),' -K ',num2str(param.K),' -T ',testfile,' -D ',outputtest,' ',trainfile,' ',modelfile]);
    [a,trnOut]= system(['universvm',' -K ',num2str(param.K),' -D ',outputtrain,' -F ',modelfile,' ',trainfile]);
    [Rpred,Remp,model]= readOutputStr(tstOut,trnOut,modelfile,dim);
    
    case 'rbf',
    [a,tstOut] = system(['universvm',' -c ',num2str(param.c),' -t ',num2str(2),' -g ',num2str(param.g),' -k ',num2str(param.k),' -K ',num2str(param.K),' -T ',testfile,' -D ',outputtest,' ',trainfile,' ',modelfile]);
    [a,trnOut]= system(['universvm',' -K ',num2str(param.K),' -D ',outputtrain,' -F ',modelfile,' ',trainfile]);
    [Rpred,Remp,model]= readOutputStr(tstOut,trnOut,modelfile,dim);
    
    case 'poly',
    [a,tstOut] = system(['universvm',' -c ',num2str(param.c),' -t ',num2str(1),' -d ',num2str(param.d),' -r ',num2str(1),' -k ',num2str(param.k),' -K ',num2str(param.K),' -T ',testfile,' -D ',outputtest,' ',trainfile,' ',modelfile]);
    [a,trnOut]= system(['universvm',' -K ',num2str(param.K),' -D ',outputtrain,' -F ',modelfile,' ',trainfile]);
    [Rpred,Remp,model]= readOutputStr(tstOut,trnOut,modelfile,dim);
    
    otherwise,error('This type of Kernel is not supported');
end



% function [Rpred,Remp,model] =runUsvm(trainfile,testfile,univfile,param,modelfile,outputtrain,outputtest,dim)
% %--------------------------------------------------------------------------
% % This part of the program will be called internally
% % In this case the number of parameters that need to be specified are:-
% % param.c= This is the C parameter for the SVM
% % param.C= This is the C* parameter for the Universum samples.
% % param.G= This is the epsilon value of the Universum optimization
% %          formulation.
% % param.t= This specifies the type of kernel function.
% % param.d= This will specify the degree of the polynomial Kernel.
% % param.g= This will specify the radius of the kernel(Radial Basis).
% % Call Universum as:-
% %   universvm [options] trainfile modelfile
% %   universvm [options] -F model testfile
% %--------------------------------------------------------------------------
% 
% switch(param.t)
%     case 'linear',
%     [a,tstOut] = system(['universvm',' -c ',num2str(param.c),' -C ',num2str(param.C),' -G ',num2str(param.G),' -T ',testfile,' -D ',outputtest,' -U ',univfile,' ',trainfile,' ',modelfile]);
%     [a,trnOut]= system(['universvm',' -D ',outputtrain,' -F ',modelfile,' ',trainfile]);
%     [Rpred,Remp,model]= readOutputStr(tstOut,trnOut,modelfile,dim);
%     
%     case 'rbf',
%     [a,tstOut] = system(['universvm',' -c ',num2str(param.c),' -t ',num2str(2),' -g ',num2str(param.g),' -C ',num2str(param.C),' -G ',num2str(param.G),' -T ',testfile,' -D ',outputtest,' -U ',univfile,' ',trainfile,' ',modelfile]);
%     [a,trnOut]= system(['universvm',' -D ',outputtrain,' -F ',modelfile,' ',trainfile]);
%     [Rpred,Remp,model]= readOutputStr(tstOut,trnOut,modelfile,dim);
%     
%     case 'poly',
%     [a,tstOut] = system(['universvm',' -c ',num2str(param.c),' -t ',num2str(1),' -d ',num2str(param.d),' -r ',num2str(1),' -C ',num2str(param.C),' -G ',num2str(param.G),' -T ',testfile,' -D ',outputtest,' -U ',univfile,' ',trainfile,' ',modelfile]);
%     [a,trnOut]= system(['universvm',' -D ',outputtrain,' -F ',modelfile,' ',trainfile]);
%     [Rpred,Remp,model]= readOutputStr(tstOut,trnOut,modelfile,dim);
%     
%     otherwise,error('This type of Kernel is not supported');
% end


function [Rpred,Remp,model] =runNSTDUsvm(trainfile,testfile,univfile,param,modelfile,outputtrain,outputtest,dim)
%--------------------------------------------------------------------------
% This part of the program will be called internally
% In this case the number of parameters that need to be specified are:-
% param.c= This is the C parameter for the SVM
% param.C= This is the C* parameter for the Universum samples.
% param.G= This is the epsilon value of the Universum optimization
%          formulation.
% param.t= This specifies the type of kernel function.
% param.d= This will specify the degree of the polynomial Kernel.
% param.g= This will specify the radius of the kernel(Radial Basis).
% param.k= This is the ratio of Cfp/Cfn
% param.K= This is the ration of Cfp/Cfn (to compute the accuracy)
% Call Universum as:-
%   universvm [options] trainfile modelfile
%   universvm [options] -F model testfile
%--------------------------------------------------------------------------
switch(param.t)
    case 'linear',
    [a,tstOut] = system(['universvm',' -c ',num2str(param.c),' -C ',num2str(param.C),' -G ',num2str(param.G),' -k ',num2str(param.k),' -K ',num2str(param.K),' -N ',num2str(param.N),' -T ',testfile,' -D ',outputtest,' -U ',univfile,' ',trainfile,' ',modelfile]);
    [a,trnOut]= system(['universvm',' -K ',num2str(param.K),' -D ',outputtrain,' -F ',modelfile,' ',trainfile]);
    [Rpred,Remp,model]= readOutputStr(tstOut,trnOut,modelfile,dim);
    
    case 'rbf',
    [a,tstOut] = system(['universvm',' -c ',num2str(param.c),' -t ',num2str(2),' -g ',num2str(param.g),' -C ',num2str(param.C),' -G ',num2str(param.G),' -k ',num2str(param.k),' -K ',num2str(param.K),' -N ',num2str(param.N),' -T ',testfile,' -D ',outputtest,' -U ',univfile,' ',trainfile,' ',modelfile]);
    [a,trnOut]= system(['universvm',' -K ',num2str(param.K),' -D ',outputtrain,' -F ',modelfile,' ',trainfile]);
    [Rpred,Remp,model]= readOutputStr(tstOut,trnOut,modelfile,dim);
    
    case 'poly',
    [a,tstOut] = system(['universvm',' -c ',num2str(param.c),' -t ',num2str(1),' -d ',num2str(param.d),' -r ',num2str(1),' -C ',num2str(param.C),' -G ',num2str(param.G),' -k ',num2str(param.k),' -K ',num2str(param.K),' -N ',num2str(param.N),' -T ',testfile,' -D ',outputtest,' -U ',univfile,' ',trainfile,' ',modelfile]);
    [a,trnOut]= system(['universvm',' -K ',num2str(param.K),' -D ',outputtrain,' -F ',modelfile,' ',trainfile]);
    [Rpred,Remp,model]= readOutputStr(tstOut,trnOut,modelfile,dim);
    
    otherwise,error('This type of Kernel is not supported');
end
