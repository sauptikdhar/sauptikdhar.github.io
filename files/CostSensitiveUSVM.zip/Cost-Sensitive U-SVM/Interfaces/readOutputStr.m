function [Rpred,Remp,model]= readOutputStr(tstErrstatus,trnErrstatus,modelfile,dim)
%--------------------------------------------------------------------------
% AUTHOR: SAUPTIK DHAR
% DESCRIPTION:- 
%[Rpred,Remp,model]= readOutputFiles(tstErrstatus,trnErrstatus,modelfile)
% This interface is used to read the output strings and load the
% variables.This interface is used internally!
% INPUT:-
%tstErrstatus,trnErrstatus,modelfile: These are the output strings
% dim= Dimension of the input X.
% OUTPUT:-
%Rpred,Remp,model :- These are the variables to be loaded!
%--------------------------------------------------------------------------

% Rpred
index = strfind(tstErrstatus,'Accuracy= ');
tstErrstatus = tstErrstatus(index+10:end);
Rpred= sscanf(tstErrstatus,'%f');

% Remp
index = strfind(trnErrstatus,'Accuracy= ');
trnErrstatus = trnErrstatus(index+10:end);
Remp= sscanf(trnErrstatus,'%f');

%model
[model] = modelfileread(modelfile,dim);