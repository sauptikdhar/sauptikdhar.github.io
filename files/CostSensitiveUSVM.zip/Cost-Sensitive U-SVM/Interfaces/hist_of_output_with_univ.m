function h=hist_of_output_with_univ(dataProj,dataProjuniv,N_cls1,N_cls2)
%--------------------------------------------------------------------------
% AUTHOR: WUYANG DAI
% DESCRIPTION: 
%   h=hist_of_dataProj_with_univ(dataProj,dataProjuniv,N_cls1,N_cls2)
% This interface is used to plot he projection diagram.
% INPUT:-
%   dataProj= This is the projection data for training data.
%   dataProjuniv= This is the projection data for universum samples.
%   N_cls1 =is the number of samples of class 1[+1]
%   N_cls2 =is the number of samples of class 2[-1]
% dataProj:-
%   h= Handler for the figure.
% Note:- all the data projection values of the class 1 should preceed the 
%       projection values of class 2 in the matrix dataProj.Moreover unlike
%       hist_of_output this is a normalized Histogram.
%--------------------------------------------------------------------------

cls1proj = dataProj(1:N_cls1);
cls2proj = dataProj(N_cls1+1:N_cls1+N_cls2);

[stat1,x1] = hist(cls1proj);
[stat2,x2] = hist(cls2proj);
[statu,xu] = hist(dataProjuniv);
stat1 = stat1/N_cls1;
stat2 = stat2/N_cls2;
statu = statu/length(dataProjuniv);

h=figure;
hold on;
mid_height = (max([stat1,stat2]) + min([stat1,stat2]))/2;
cls1h = mid_height*ones(size(cls1proj,1),size(cls1proj,2));
cls2h = mid_height*ones(size(cls2proj,1),size(cls2proj,2));
clsuh = mid_height*ones(size(dataProjuniv,1),size(dataProjuniv,2));
plot(cls1proj,cls1h,'bo');
plot(cls2proj,cls2h,'rx');
plot(dataProjuniv,clsuh,'kx');

plot(x1,stat1,'b');
plot(x2,stat2,'r');
plot(xu,statu,'k');
plot([0,0],[0,max([stat1,stat2])],'k');
plot([-1,-1],[0,max([stat1,stat2])],'k-.');
plot([+1,+1],[0,max([stat1,stat2])],'k-.');