function dispAllFiles()
%--------------------------------------------------------------------------
% AUTHOR:- SAUPTIK DHAR
% DESCRIPTION:-
% dispAllFiles()
%
% This is a interface that will show all the available files in the folder
% (/Engine/Data).
% INPUT:-
%   None
% OUTPUT:-
%   None
%--------------------------------------------------------------------------
d=dir('*.dat');
nfiles=size(d,1);
display(['There are ',num2str(nfiles),' files available']);
for i=1:nfiles
    fprintf('%s\n',d(i).name);
end
