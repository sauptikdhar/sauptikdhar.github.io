function [success]=createFile(filename)
%--------------------------------------------------------------------------
% AUTHOR:- SAUPTIK DHAR
% DESCRIPTION:-
% [success]=createFile(filename)
%
% This is an interface create a File with some filename
%
% INPUT:-
%   filename:- This specifies the name of the file that will be created
% OUTPUT:-
%   sucess:- This indicates the success/failure in writing the file.
%           0= Failure, 1= Success.
%--------------------------------------------------------------------------

success=1;  % No need to update this explicitly!!!
fid = fopen([filename],'w');
fclose(fid);