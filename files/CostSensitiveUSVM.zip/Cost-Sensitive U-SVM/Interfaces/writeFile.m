function [success]=writeFile(data,filename)
%--------------------------------------------------------------------------
% AUTHOR:- SAUPTIK DHAR
% DESCRIPTION:-
% [sucess]=writeFile(Data)
%
% This is an interface to write a File with the data provided by the
% structure data.This will store the files in the folder (/Engine).The
% data is stored in the LIBSVM fileformat.
%
% INPUT:-
%   data:- This is a structure with the following fields.
%       data.X:- These are the X values of the data.
%       data.y:- These are the y values of the data.
%   filename:- This specifies the name of the file in which the data has
%   been stored.
% OUTPUT:-
%   sucess:- This indicates the success/failure in writing the file.
%           0= Failure, 1= Success.
%--------------------------------------------------------------------------

success=1;  % No need to update this explicitly!!!
fid = fopen([filename],'w');


for i = 1:size(data.X,1)
    fprintf(fid,'%d',data.y(i));
    for j = 1:size(data.X,2)
        fprintf(fid,' %d:%f',j,data.X(i,j));
    end
    fprintf(fid,'\n');
end 
fclose(fid);