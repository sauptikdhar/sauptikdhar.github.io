function [output] = outputfileread(outputfile)
%--------------------------------------------------------------------------
% AUTHOR: WUYANG DAI
% DESCRIPTION:
%   [output] = outputfileread(outputfile)
% This interface is used to read the output files to get the projection of
% the output values.
% INPUT:-
%   outputfile:- This is the outputfile obtained using the universvm.
% OUTPUT:-
%   output:- This is the output containing the projection values.
%--------------------------------------------------------------------------
format long;
fid = fopen(outputfile);
line = fgetl(fid);
% the first line is empty
line = fgetl(fid);
% the second line is # function values
line = fgetl(fid);
% the 3rd line contains all the function values


index = strfind(line,'= [ ');
line = line(index+4:end);
cnt = 1;
while (length(line) > 2)
    [output(cnt),count,errmsg,index] = sscanf(line,'%f',1);
    line = line(index+2:end);
    cnt = cnt+1;
end

fclose(fid);
format short;