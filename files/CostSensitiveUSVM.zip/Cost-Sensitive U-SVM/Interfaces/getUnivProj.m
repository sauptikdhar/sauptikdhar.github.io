function [dataProjuniv]=getUnivProj(model,univdata)
%--------------------------------------------------------------------------
%AUTHOR:- Sauptik Dhar
%DESCRIPTION:
%   [dataProjuniv]=getUnivProj(model,univdata)
% This interface is used to project the universum samples along the normal
% vector.
% INPUT:-
%   model= This is the model obtained after using the rununivresvm
%   interface.
%   univdata= This is the universum samples.
% OUTPUT:-
%   dataProjuniv= This is the Projection of the Universum data.
%--------------------------------------------------------------------------

dummyUnivdata=univdata;
dummyUnivdata.y(find(dummyUnivdata.y==-2))=1;
univfile='dummyuniversum.dat';
outputuniv='OutputUniv.out';
[success]=writeFile(dummyUnivdata,univfile);
[success]=createFile(outputuniv);

[a,univ]= system(['universvm',' -D ',outputuniv,' -F ',model.modelfile,' ',univfile]);
dataProjuniv= outputfileread(outputuniv);
