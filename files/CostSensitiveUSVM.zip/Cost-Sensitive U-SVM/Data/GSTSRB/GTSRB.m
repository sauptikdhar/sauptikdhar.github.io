function [trndata,valdata,tstdata,univdata]=GTSRB(ntrn,nval,ntst,uid,nuniv)

load raw_HOG_data
class1=data50.X;

[M]=size(class1,1);
[index]=randperm(M);

[trnindex]=index(1:ntrn);
[valindex]=index(ntrn+1:nval+ntrn);
[tstindex]=index(nval+ntrn+1:nval+ntrn+ntst); 

trndata.X=class1(trnindex,:);trndata.y=ones(ntrn,1);
valdata.X=class1(valindex,:);valdata.y=ones(nval,1);
tstdata.X=class1(tstindex,:);tstdata.y=ones(ntst,1);


class2=data80.X;

[M]=size(class2,1);
[index]=randperm(M);

[trnindex]=index(1:ntrn);
[valindex]=index(ntrn+1:nval+ntrn);
[tstindex]=index(nval+ntrn+1:nval+ntrn+ntst); 

trndata.X=[trndata.X;class2(trnindex,:)];trndata.y=[trndata.y;-ones(ntrn,1)];
valdata.X=[valdata.X;class2(valindex,:)];valdata.y=[valdata.y;-ones(nval,1)];
tstdata.X=[tstdata.X;class2(tstindex,:)];tstdata.y=[tstdata.y;-ones(ntst,1)];

univsize=nuniv;

switch(uid)
    case 30,univ=data30.X;
        if(size(univ,1)<univsize)
            fprintf('\nExceeded the Universum size!\n');
            univdata.X=univ;
            univdata.y=-2*ones(size(univdata.X,1),1);
        else
            [M]=size(univ,1);
            [index]=randperm(M);
            [univindex]=index(1:univsize);
            univdata.X=univ(univindex,:);
            univdata.y=-2*ones(size(univdata.X,1),1);
        end
    case 50,univ=data50.X;
        if(size(univ,1)<univsize)
            fprintf('\nExceeded the Universum size!\n');
            univdata.X=univ;
            univdata.y=-2*ones(size(univdata.X,1),1);
        else
            [M]=size(univ,1);
            [index]=randperm(M);
            [univindex]=index(1:univsize);
            univdata.X=univ(univindex,:);
            univdata.y=-2*ones(size(univdata.X,1),1);
        end
    case 60,univ=data60.X;
        if(size(univ,1)<univsize)
            fprintf('\nExceeded the Universum size!\n');
            univdata.X=univ;
            univdata.y=-2*ones(size(univdata.X,1),1);
        else
            [M]=size(univ,1);
            [index]=randperm(M);
            [univindex]=index(1:univsize);
            univdata.X=univ(univindex,:);
            univdata.y=-2*ones(size(univdata.X,1),1);
        end
    case 70,univ=data70.X;
        if(size(univ,1)<univsize)
            fprintf('\nExceeded the Universum size!\n');
            univdata.X=univ;
            univdata.y=-2*ones(size(univdata.X,1),1);
        else
            [M]=size(univ,1);
            [index]=randperm(M);
            [univindex]=index(1:univsize);
            univdata.X=univ(univindex,:);
            univdata.y=-2*ones(size(univdata.X,1),1);
        end
        
        case 80,univ=data80.X;
        if(size(univ,1)<univsize)
            fprintf('\nExceeded the Universum size!\n');
            univdata.X=univ;
            univdata.y=-2*ones(size(univdata.X,1),1);
        else
            [M]=size(univ,1);
            [index]=randperm(M);
            [univindex]=index(1:univsize);
            univdata.X=univ(univindex,:);
            univdata.y=-2*ones(size(univdata.X,1),1);
        end
        
    otherwise,fprintf('This version of Universum samples not supported\n');
end