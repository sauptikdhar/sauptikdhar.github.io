function [RPred,RPredU,Remp,RempU,Finmodel,FinmodelU,Finoutput,FinoutputU,optparam]=ExpwithValSet(trndata,valdata,tstdata,univdata,param)
%--------------------------------------------------------------------------
% AUTHOR:- SAUPTIK DHAR
% DESCRIPTION:-
%[Pred,PredU,Finmodel,FinmodelU,Finoutput,FinoutputU,optparam]=ExpwithValSet(trndata,valdata,tstdata,univdata,param)
% This is a General Experimental Setup in which model selection is done
% based on the validation data provided.
% INPUT:-
%   trndata:- This is the training data which has the following fields.
%           trndata.X=The X values for the training data.
%           trndata.y=The y labels for the training data [+1,-1]
%   valdata:- This is the validation data.(it has the same fields as trndata)
%   tstdata:- This is the test data.(it has the same fields as trndata)
%   univdata:-This is the universum samples.(it has the same fields as trndata.)
%   param:- This is the set of parameters used for the model.It should
%   mainly have the following parameters.
%       param.cset= This is the set of C values.This is a vector.
%       param.Cset= This is the set of C* values.This is a vector.
%       param.Gset= This is the set of Epsilon values.This is a vector.
%       param.t= This is the type of kernel to be used.It could be either
%       'linear','rbf','poly'.
%       param.dset= This is the set of parameters for a Polynomial Kernel.
%       param.gset= This is the set of parameters for the RBF Kernel.
%   Note:- In the case of Universum samples the y labels should be -2.
% OUTPUT:-
%   RPred:- This is the Prediction accuracy(for STANDARD SVM).
%   RPredU:-This is the Prediction Accuracy(for UNIVERSUM SVM).
%   Remp:-This is the Emperical Risk(for STANDARD SVM).
%   RempU:-This is the Emperical Risk(for UNIVERSUM SVM).
%   FinModel:- This is the Final STANDARD SVM Model.
%   FinModelU:- This is the Final Universum SVM Model.
%   Finoutput:- These contain the Projection data for the STANDARD SVM
%   Model.It has the following following fields
%       Finoutput.train.projection= The projection of the Training data.
%       Finoutput.test.projection= The Projection of the Test data.
%       Finoutput.univ.projection= The Projection of the Univ data.
%   FinoutputU:- This contain the Projection values for the Universum SVM
%   It has the same fields as Finoutput.
%   optparam:- The optimal parameters for the dataset.
%--------------------------------------------------------------------------



% CREATE THE DATA FILES    
switch(param.t)
    case 'linear',
        [RPred,RPredU,Remp,RempU,Finmodel,FinmodelU,Finoutput,FinoutputU,optparam]=ExpwithValSetLinear(trndata,valdata,tstdata,univdata,param);
    case 'rbf',
        [RPred,RPredU,Remp,RempU,Finmodel,FinmodelU,Finoutput,FinoutputU,optparam]=ExpwithValSetRBF(trndata,valdata,tstdata,univdata,param);
    case 'poly',
        [RPred,RPredU,Remp,RempU,Finmodel,FinmodelU,Finoutput,FinoutputU,optparam]=ExpwithValSetPoly(trndata,valdata,tstdata,univdata,param);
        %[Pred,PredU,Finmodel,FinmodelU,Finoutput,FinoutputU]=ExpwithValSetPoly(trndata,valdata,tstdata,univdata,param);
end
 

            