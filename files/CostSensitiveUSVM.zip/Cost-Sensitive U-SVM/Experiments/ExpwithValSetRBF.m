function [RPred,RPredU,Remp,RempU,Finmodel,FinmodelU,Finoutput,FinoutputU,optparam]=ExpwithValSetRBF(trndata,valdata,tstdata,univdata,param)
%--------------------------------------------------------------------------
% AUTHOR:- SAUPTIK DHAR
% DESCRIPTION:-
% [Pred,PredU,Finmodel,FinmodelU,Finoutput,FinoutputU]=ExpwithValSetRBF(trndata,valdata,tstdata,univdata,param)
% This is a General Experimental Setup in which model selection is done
% based on the validation data provided.In this case the Kernel Type is
% RBF.
% INPUT:-
%   trndata:- This is the training data which has the following fields.
%           trndata.X=The X values for the training data.
%           trndata.y=The y labels for the training data [+1,-1]
%   valdata:- This is the validation data.(it has the same fields as trndata)
%   tstdata:- This is the test data.(it has the same fields as trndata)
%   univdata:-This is the universum samples.(it has the same fields as trndata.)
%   param:- These are the set of parameters.
%       param.cset= This is the set of C values.This is a vector.
%       param.gset= This is the set of g(radius) values for the RBF
%       function.
%       param.Cset= This is the set of C* values.This is a vector.
%       param.Gset= This is the set of Epsilon values.This is a vector.
%       
%   Note:- In the case of Universum samples the y labels should be -2.
% OUTPUT:-
%   RPred:- This is the Prediction Risk(for STANDARD SVM).
%   RPredU:-This is the Prediction Risk(for UNIVERSUM SVM).
%   Remp:- This is the Emperical Risk(for STANDARD SVM).
%   RempU:- This is the Emperical Risk(for Universum SVM).
%   FinModel:- This is the Final STANDARD SVM Model.
%   FinModelU:- This is the Final Universum SVM Model.
%   Finoutput:- These contain the Projection data for the STANDARD SVM
%   Model.It has the following following fields
%       Finoutput.train.projection= The projection of the Training data.
%       Finoutput.test.projection= The Projection of the Test data.
%       Finoutput.univ.projection= The Projection of the Univ data.
%   FinoutputU:- This contain the Projection values for the Universum SVM
%   It has the same fields as Finoutput.
%   optparam:- The optimal parameters for the dataset.
% NOTE:- It will also display the univariate projections.
%--------------------------------------------------------------------------

cleanData;
%INITIALIZE
    RPred=100;
    RPredU=100;
    Remp=100;
    RempU=100;
    Finmodel=struct;
    FinmodelU=struct;
    Finoutput=struct;
    FinoutputU=struct;
    optparam=struct;


% CREATE THE DATA FILES

    trainfile='training.dat';   
    testfile='test.dat';
    valfile='val.dat';
    univfile='universum.dat';
    fprintf('.....Writing Files....\n');
    [success]=writeFile(trndata,trainfile);
    [success]=writeFile(valdata,valfile);
    [success]=writeFile(tstdata,testfile);
    [success]=writeFile(univdata,univfile);
    dim=size(trndata.X,2);

% DEFINE THE PARAMETERS
cset=param.cset;
gset=param.gset;


if(isempty(cset)|| isempty(gset));
else
        fprintf('........Starting STANDARD SVM(RBF)...........\n');
        index1=0;

        for c=cset
            index1=index1+1;
            index2=0;
            for g=gset
                 index2=index2+1;
                 param.c=c;
                 param.g=g;
                 [Rpred(index1,index2),temp,model,output] =rununiversvm(1,trainfile,valfile,univfile,param,dim); 
            end
        end
        param=getOptimalParam(Rpred,cset,gset,param); 
        [Pred,PredTr,Finmodel,Finoutput] =rununiversvm(1,trainfile,testfile,univfile,param,dim);

         
        [dataProjunivproj]=getUnivProj(Finmodel,univdata);
        Finoutput.univ.projection=dataProjunivproj;
RPred=100-Pred;
Remp=100-PredTr;
end

Cset=(param.c)*(param.Cset); % Search for the optimal C* keeping C constant.
Gset=param.Gset;

if(isempty(Cset)|| isempty(Gset));
else
    fprintf('........Starting UNIVERSUM SVM(RBF)...........\n');

        index2=0;
        for C=Cset
            index2=index2+1;
            index3=0;
            for G=Gset
                index3=index3+1;
                param.C=C;
                param.G=G;
                [RpredU(index2,index3),temp,model,output] =rununiversvm(2,trainfile,valfile,univfile,param,dim);
            end
        end

    param=getOptimalUParam(RpredU,Cset,Gset,param);
    [PredU,PredUTr,FinmodelU,FinoutputU] =rununiversvm(2,trainfile,testfile,univfile,param,dim);

     
    [dataProjunivUproj]=getUnivProj(FinmodelU,univdata);
    FinoutputU.univ.projection=dataProjunivUproj;

   
RPredU=100-PredU;
RempU=100-PredUTr;
end
 optparam=param;


function [param]=getOptimalParam(Rpred,cset,gset,param)
Rpredopt=0;
    for j=size(Rpred,1):-1:1
        for k=size(Rpred,2):-1:1
            % LETS TAKE THE SMALLEST c and SMALLEST g
            if(Rpred(j,k)>=Rpredopt)
                param.c=cset(j);
                param.g=gset(k);
                Rpredopt=Rpred(j,k);
            end
        end
    end


function [param]=getOptimalUParam(Rpred,Cset,Gset,param)
Rpredopt=0;
    for j=size(Rpred,1):-1:1
        for k=size(Rpred,2):-1:1
            % LETS TAKE THE SMALLEST C* and G(model selection)
            if(Rpred(j,k)>=Rpredopt)
                param.C=Cset(j);
                param.G=Gset(k);
                Rpredopt=Rpred(j,k);
            end
        end
    end

            