
function [RPred_1,RPredU_1,Finmodel_1,FinmodelU_1,Finoutput_1,FinoutputU_1,optparam_1,NRPred_1,NRPredU_1,NRPredU_2,NRPredU_3,NRPredU_4,NFinmodel_1,NFinmodelU_1,NFinmodelU_2,NFinmodelU_3,NFinmodelU_4,NFinoutput_1,NFinoutputU_1,NFinoutputU_2,NFinoutputU_3,NFinoutputU_4,Noptparam_1,Noptparam_2,Noptparam_3,Noptparam_4,NFinoutput_2,NFinoutput_3,NFinoutput_4]=example6U_RBF()


%--------------------------------------------------------------------------
% AUTHOR:- SAUPTIK DHAR
% DESCRIPTION:-
% 
% Experiment FOR MNIST data for RBF
%--------------------------------------------------------------------------

cleanData();

for expno=1:3
    % CREATE THE DATA FILES
    
      [trndata,valdata,tstdata,udata_1]= mnistdata(8,5,1,500,500,[],1000);
      [ta,tb,tc,udata_2]= mnistdata(5,8,3,1,1,[],1000);
      [ta,tb,tc,udata_3]= mnistdata(5,8,6,1,1,[],1000);
      [udata_4]=generateUnivSamp(trndata,1000,0.5);


%*************** STD SVM/UNIVERSUM *******************************
    % DEFINE THE PARAMETERS

    param.cset=2.^[2:6];
    param.Cset=[];%2.^[-20:2:6];
    param.gset=2.^-6;
    param.Gset=[];%[0];


    param.t='rbf';
    param.K=0.5;
    param.k=1;
    K=param.K;
    param.N=0;
    param.is_regr=0;
    %RUN EXPERIMENT
    param.Cset=[];param.Gset=[];
    [RPred_1(expno),RPredU_1(expno),Remp(expno),RempU_1(expno),Finmodel_1(expno),FinmodelU_1(expno),Finoutput_1(expno),FinoutputU_1(expno),optparam_1(expno)]=ExpwithValSet(trndata,valdata,tstdata,udata_1,param);
    
    [rFpTs,rFnTs,e1]=computeMetrics(tstdata.y,Finoutput_1(expno).test.projection,K);
    [rFpTr,rFnTr,e2]=computeMetrics(trndata.y,Finoutput_1(expno).train.projection,K);
        
    fprintf('#################### STANDARD SETTING (C=%f, g=%f) ######################\n',log2(optparam_1(expno).c),log2(optparam_1(expno).g));
    fprintf('-------------------------------------------------------------\n');
    fprintf('\nExp no= %d, Pred Risk(SVM)=%f\n',expno,RPred_1(expno));
    fprintf('*************** SVM(EXPNO=%d)***************\n',expno);
    fprintf('SVM::Test data----> Ratio. of false positive=%d and Ratio of false negative= %d \n',rFpTs,rFnTs);
    fprintf('SVM::Train data----> Ratio of false positive=%d and Ratio of false negative= %d \n',rFpTr,rFnTr);
    
  
    
    %*************** NON.STD SVM/UNIVERSUM *******************************
    param.cset=2.^[-1:3];
    param.gset=2.^-6;
    param.Cset=2.^[-20,-4:2];
    param.Gset=[0,0.01,0.1,0.2];
    
    param.K=0.5;
    param.k=0.5;
    K=param.K;
    param.N=1;
    %RUN EXPERIMENT
    [NRPred_1(expno),NRPredU_1(expno),NRemp_1(expno),NRempU_1(expno),NFinmodel_1(expno),NFinmodelU_1(expno),NFinoutput_1(expno),NFinoutputU_1(expno),Noptparam_1(expno)]=ExpwithValSet(trndata,valdata,tstdata,udata_1,param);
    
    param.cset=Noptparam_1(expno).c;
    param.gset=Noptparam_1(expno).g; 
    param.Cset=2.^[-20,-4:1];
    [u,NRPredU_2(expno),v,NRempU_2(expno),w,NFinmodelU_2(expno),NFinoutput_2(expno),NFinoutputU_2(expno),Noptparam_2(expno)]=ExpwithValSet(trndata,valdata,tstdata,udata_2,param);
    param.Cset=2.^[-20,-4:1];
    [u,NRPredU_3(expno),v,NRempU_3(expno),w,NFinmodelU_3(expno),NFinoutput_3(expno),NFinoutputU_3(expno),Noptparam_3(expno)]=ExpwithValSet(trndata,valdata,tstdata,udata_3,param);
    param.Cset=2.^[-20,-4:1];
    [u,NRPredU_4(expno),v,NRempU_4(expno),w,NFinmodelU_4(expno),NFinoutput_4(expno),NFinoutputU_4(expno),Noptparam_4(expno)]=ExpwithValSet(trndata,valdata,tstdata,udata_4,param);
    
    [rFpTs,rFnTs,e1]=computeMetrics(tstdata.y,NFinoutput_1(expno).test.projection,K);
    [rFpTr,rFnTr,e2]=computeMetrics(trndata.y,NFinoutput_1(expno).train.projection,K);
        
    fprintf('#################### NON.STANDARD SETTING (C=%f, g=%f)######################\n',log2(Noptparam_1(expno).c),log2(Noptparam_1(expno).g));
    fprintf('-------------------------------------------------------------\n');
    fprintf('\nExp no= %d, Pred Risk(NSVM)=%f, Pred Risk(NUSVM1)=%f, Pred Risk(NUSVM3)=%f, Pred Risk(NUSVM6)=%f, Pred Risk(NUSVMRA)=%f\n',expno,NRPred_1(expno),NRPredU_1(expno),NRPredU_2(expno),NRPredU_3(expno),NRPredU_4(expno));
    fprintf('*************** N.SVM(EXPNO=%d)***************\n',expno);
    fprintf('SVM::Test data----> Ratio. of false positive=%d and Ratio of false negative= %d \n',rFpTs,rFnTs);
    fprintf('SVM::Train data----> Ratio of false positive=%d and Ratio of false negative= %d \n',rFpTr,rFnTr);
    
    [rFpTsU,rFnTsU,e3]=computeMetrics(tstdata.y,NFinoutputU_1(expno).test.projection,K);
    [rFpTrU,rFnTrU,e4]=computeMetrics(trndata.y,NFinoutputU_1(expno).train.projection,K);
    
    fprintf('*************** DIGIT 1(EXPNO=%d) ***************\n',expno);
    fprintf('U SVM::Test data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTsU,rFnTsU);
    fprintf('U SVM::Train data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTrU,rFnTrU);
    
    [rFpTsU,rFnTsU,e3]=computeMetrics(tstdata.y,NFinoutputU_2(expno).test.projection,K);
    [rFpTrU,rFnTrU,e4]=computeMetrics(trndata.y,NFinoutputU_2(expno).train.projection,K);
    
    fprintf('*************** DIGIT 3(EXPNO=%d) ***************\n',expno);
    fprintf('U SVM::Test data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTsU,rFnTsU);
    fprintf('U SVM::Train data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTrU,rFnTrU);
    
    [rFpTsU,rFnTsU,e3]=computeMetrics(tstdata.y,NFinoutputU_3(expno).test.projection,K);
    [rFpTrU,rFnTrU,e4]=computeMetrics(trndata.y,NFinoutputU_3(expno).train.projection,K);
    
    fprintf('*************** DIGIT 6(EXPNO=%d)***************\n',expno);
    fprintf('U SVM::Test data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTsU,rFnTsU);
    fprintf('U SVM::Train data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTrU,rFnTrU);
    
    [rFpTsU,rFnTsU,e3]=computeMetrics(tstdata.y,NFinoutputU_4(expno).test.projection,K);
    [rFpTrU,rFnTrU,e4]=computeMetrics(trndata.y,NFinoutputU_4(expno).train.projection,K);
    
    fprintf('*************** RA(EXPNO=%d) ***************\n',expno);
    fprintf('U SVM::Test data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTsU,rFnTsU);
    fprintf('U SVM::Train data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTrU,rFnTrU);
    
 
       
end



    
function [rFp,rFn,error,nFp,nFn]=computeMetrics(y,projection,K)
y_est=sign(projection');
y_est(find(y_est==0))=1;
y_true=y;
nFn=length(find(y_est<y_true));
nFp=length(find(y_est>y_true));

n_plus=length(find(y_true>0));
n_minus=length(find(y_true<0));
error=(K*nFp+nFn)/(K*n_minus+n_plus);
rFp=nFp;
rFn=nFn;