
function [RPred_1,Finmodel_1,Finoutput_1,optparam_1,NRPred_1,NRPredU_1,NRPredU_2,NRPredU_4,NRPredU_11,NRPredU_21,NRPredU_41,NFinmodel_1,NFinmodelU_1,NFinmodelU_2,NFinmodelU_4,NFinmodelU_11,NFinmodelU_21,NFinmodelU_41,NFinoutput_1,NFinoutput_2,NFinoutput_4,NFinoutput_11,NFinoutput_21,NFinoutput_41,NFinoutputU_1,NFinoutputU_2,NFinoutputU_4,NFinoutputU_11,NFinoutputU_21,NFinoutputU_41,Noptparam_1,Noptparam_2,Noptparam_4,Noptparam_11,Noptparam_21,Noptparam_41]=exampleGTSRB_NSTD_LIN_COMP()

%[RPred_1,RPredU_1,Finmodel_1,FinmodelU_1,Finoutput_1,FinoutputU_1,optparam_1,NRPred_1,NRPredU_1,NFinmodel_1,NFinmodelU_1,NFinoutput_1,NFinoutputU_1,Noptparam_1]=example6U_NSTD_LIN()
%[RPred_1,RPredU_1,Finmodel_1,FinmodelU_1,Finoutput_1,FinoutputU_1,optparam_1,NRPred_1,NRPredU_1,NRPredU_2,NRPredU_3,NRPredU_4,NFinmodel_1,NFinmodelU_1,NFinmodelU_2,NFinmodelU_3,NFinmodelU_4,NFinoutput_1,NFinoutputU_1,NFinoutputU_2,NFinoutputU_3,NFinoutputU_4,Noptparam_1,Noptparam_2,Noptparam_3,Noptparam_4]=example6U_NSTD_LIN()
%--------------------------------------------------------------------------
% AUTHOR:- SAUPTIK DHAR
% DESCRIPTION:-
%[RPred_1,RPredU_1,Finmodel_1,FinmodelU_1,Finoutput_1,FinoutputU_1,optparam_1,NRPred_1,NRPredU_1,NRPredU_2,NRPredU_3,NRPredU_4,NRPredU2_1,NRPredU2_2,NRPredU2_3,NRPredU2_4,NFinmodel_1,NFinmodelU_1,NFinmodelU_2,NFinmodelU_3,NFinmodelU_4,NFinmodelU2_1,NFinmodelU2_2,NFinmodelU2_3,NFinmodelU2_4,NFinoutput_1,NFinoutputU_1,NFinoutputU_2,NFinoutputU_3,NFinoutputU_4,NFinoutputU2_1,NFinoutputU2_2,NFinoutputU2_3,NFinoutputU2_4,Noptparam_1,Noptparam_2,Noptparam_3,Noptparam_4,Noptparam2_1,Noptparam2_2,Noptparam2_3,Noptparam2_4]=example6U_NSTD_LIN()
% [RPred,RPredNSTD,Finmodel,FinmodelNSTD,Finoutput,FinoutputNSTD,optparam,optparamNSTD]=example3NSTD()
% Experiment to compare between SVM vs N-STD SVM using hypercube data
%--------------------------------------------------------------------------

cleanData();

for expno=1:5
  


[trndata,valdata,tstdata,udata_1]=GTSRB(100,100,1000,30,1000);
[ta,tb,tc,udata_2]=GTSRB(100,100,1000,60,1000);
%[ta,tb,tc,udata_3]=GTSRB(100,100,1000,70,1000);
[udata_4]=generateUnivSamp(trndata,1000,0.5);
%valdata=tstdata;

% trndata.X=rand(10,2);
% trndata.y=sign(randn(10,1));
% tstdata=trndata;
% valdata=trndata;
% [udata_1]=generateUnivSamp(trndata,10,0.5);
% udata_2=udata_1;udata_4=udata_1;

%*************** STD SVM/UNIVERSUM *******************************
    % DEFINE THE PARAMETERS

    param.cset=2.^[-3:3];
    param.Cset=[];
    param.Gset=[];


    param.t='linear';
    param.K=0.1;
    param.k=1;
    K=param.K;
    param.N=0;
    param.is_regr=0;
    
    %RUN EXPERIMENT
    
    [RPred_1(expno),RPredU_1(expno),Remp(expno),RempU_1(expno),Finmodel_1(expno),FinmodelU_1(expno),Finoutput_1(expno),FinoutputU_1(expno),optparam_1(expno)]=ExpwithValSet(trndata,valdata,tstdata,udata_1,param);

   
    
    
    [rFpTs,rFnTs,e1]=computeMetrics(tstdata.y,Finoutput_1(expno).test.projection,K);
    [rFpTr,rFnTr,e2]=computeMetrics(trndata.y,Finoutput_1(expno).train.projection,K);
        
    fprintf('#################### STANDARD SETTING ######################\n');
    fprintf('-------------------------------------------------------------\n');
    fprintf('\nExp no= %d, Pred Risk(SVM)=%f\n',expno,RPred_1(expno));
    
    fprintf('*************** SVM(EXPNO=%d)***************\n',expno);
    fprintf('SVM::Test data----> Ratio. of false positive=%d and Ratio of false negative= %d \n',rFpTs,rFnTs);
    fprintf('SVM::Train data----> Ratio of false positive=%d and Ratio of false negative= %d \n',rFpTr,rFnTr);
    

    
    %*************** NON.STD SVM/UNIVERSUM *******************************
    
    
    param.cset=2.^[-4:3];%[-6:3];
    param.Cset=2.^[-18,[-8:0]];
    param.Gset=[0,0.03,0.3];
    
    
    param.K=0.1;
    param.k=0.1;
    K=param.K;
    param.N=0;
    param.is_regr=0;
    %RUN EXPERIMENT
   
    [NRPred_1(expno),NRPredU_1(expno),NRemp_1(expno),NRempU_1(expno),NFinmodel_1(expno),NFinmodelU_1(expno),NFinoutput_1(expno),NFinoutputU_1(expno),Noptparam_1(expno)]=ExpwithValSet(trndata,valdata,tstdata,udata_1,param);
    
    param.cset=Noptparam_1(expno).c;
   
    fprintf('1 done.\n');
    
    param.Cset=2.^[-18,[-8:0]];
    
    [u,NRPredU_2(expno),v,NRempU_2(expno),w,NFinmodelU_2(expno),NFinoutput_2(expno),NFinoutputU_2(expno),Noptparam_2(expno)]=ExpwithValSet(trndata,valdata,tstdata,udata_2,param);
    fprintf('2 done.\n');

   param.Cset=2.^[-18,[-8:0]];
    
    [u,NRPredU_4(expno),v,NRempU_4(expno),w,NFinmodelU_4(expno),NFinoutput_4(expno),NFinoutputU_4(expno),Noptparam_4(expno)]=ExpwithValSet(trndata,valdata,tstdata,udata_4,param);
    fprintf('3 done.\n');
    
    [rFpTs,rFnTs,e1]=computeMetrics(tstdata.y,NFinoutput_1(expno).test.projection,K);
    [rFpTr,rFnTr,e2]=computeMetrics(trndata.y,NFinoutput_1(expno).train.projection,K);
        
    fprintf('#################### NON.STANDARD SETTING ######################\n');
    fprintf('-------------------------------------------------------------\n');
    fprintf('\nExp no= %d, Pred Risk(NSVM)=%f, Pred Risk(NUSVM1)=%f, Pred Risk(NUSVM3)=%f, Pred Risk(NUSVMRA)=%f\n',expno,NRPred_1(expno),NRPredU_1(expno),NRPredU_2(expno),NRPredU_4(expno));
     
    fprintf('*************** N.SVM(EXPNO=%d)***************\n',expno);
    fprintf('SVM::Test data----> Ratio. of false positive=%d and Ratio of false negative= %d \n',rFpTs,rFnTs);
    fprintf('SVM::Train data----> Ratio of false positive=%d and Ratio of false negative= %d \n',rFpTr,rFnTr);
    
    [rFpTsU,rFnTsU,e3]=computeMetrics(tstdata.y,NFinoutputU_1(expno).test.projection,K);
    [rFpTrU,rFnTrU,e4]=computeMetrics(trndata.y,NFinoutputU_1(expno).train.projection,K);
    
    fprintf('*************** dig 30(EXPNO=%d) ***************\n',expno);
    fprintf('U SVM::Test data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTsU,rFnTsU);
    fprintf('U SVM::Train data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTrU,rFnTrU);
    
    [rFpTsU,rFnTsU,e3]=computeMetrics(tstdata.y,NFinoutputU_2(expno).test.projection,K);
    [rFpTrU,rFnTrU,e4]=computeMetrics(trndata.y,NFinoutputU_2(expno).train.projection,K);
    
    fprintf('*************** DIGIT 60(EXPNO=%d) ***************\n',expno);
    fprintf('U SVM::Test data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTsU,rFnTsU);
    fprintf('U SVM::Train data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTrU,rFnTrU);
    

    
    [rFpTsU,rFnTsU,e3]=computeMetrics(tstdata.y,NFinoutputU_4(expno).test.projection,K);
    [rFpTrU,rFnTrU,e4]=computeMetrics(trndata.y,NFinoutputU_4(expno).train.projection,K);
    
    fprintf('*************** RA(EXPNO=%d) ***************\n',expno);
    fprintf('U SVM::Test data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTsU,rFnTsU);
    fprintf('U SVM::Train data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTrU,rFnTrU);
    
    
    %*************** NO. WTS FOR UNIVERSUM *******************************
 
    param.cset=Noptparam_1(expno).c;
    param.N=1;
    param.Cset=2.^[-18,[-8:0]];
    [NRPred_11(expno),NRPredU_11(expno),NRemp_11(expno),NRempU_11(expno),NFinmodel_11(expno),NFinmodelU_11(expno),NFinoutput_11(expno),NFinoutputU_11(expno),Noptparam_11(expno)]=ExpwithValSet(trndata,valdata,tstdata,udata_1,param);
    
    param.cset=Noptparam_1(expno).c;
   
    fprintf('1 done.\n');
    
    param.Cset=2.^[-18,[-8:0]];
    
    [u,NRPredU_21(expno),v,NRempU_21(expno),w,NFinmodelU_21(expno),NFinoutput_21(expno),NFinoutputU_21(expno),Noptparam_21(expno)]=ExpwithValSet(trndata,valdata,tstdata,udata_2,param);
    fprintf('2 done.\n');

   param.Cset=2.^[-18,[-8:0]];
    
    [u,NRPredU_41(expno),v,NRempU_41(expno),w,NFinmodelU_41(expno),NFinoutput_41(expno),NFinoutputU_41(expno),Noptparam_41(expno)]=ExpwithValSet(trndata,valdata,tstdata,udata_4,param);
    fprintf('3 done.\n');
    
    [rFpTs,rFnTs,e1]=computeMetrics(tstdata.y,NFinoutput_11(expno).test.projection,K);
    [rFpTr,rFnTr,e2]=computeMetrics(trndata.y,NFinoutput_11(expno).train.projection,K);
        
    fprintf('#################### (No. wts)NON.STANDARD SETTING ######################\n');
    fprintf('-------------------------------------------------------------\n');
    fprintf('\nExp no= %d, Pred Risk(NSVM)=%f, Pred Risk(NUSVM1)=%f, Pred Risk(NUSVM3)=%f, Pred Risk(NUSVMRA)=%f\n',expno,NRPred_11(expno),NRPredU_11(expno),NRPredU_21(expno),NRPredU_41(expno));
     
    fprintf('*************** N.SVM(EXPNO=%d)***************\n',expno);
    fprintf('SVM::Test data----> Ratio. of false positive=%d and Ratio of false negative= %d \n',rFpTs,rFnTs);
    fprintf('SVM::Train data----> Ratio of false positive=%d and Ratio of false negative= %d \n',rFpTr,rFnTr);
    
    [rFpTsU,rFnTsU,e3]=computeMetrics(tstdata.y,NFinoutputU_11(expno).test.projection,K);
    [rFpTrU,rFnTrU,e4]=computeMetrics(trndata.y,NFinoutputU_11(expno).train.projection,K);
    
    fprintf('*************** dig 30(EXPNO=%d) ***************\n',expno);
    fprintf('U SVM::Test data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTsU,rFnTsU);
    fprintf('U SVM::Train data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTrU,rFnTrU);
    
    [rFpTsU,rFnTsU,e3]=computeMetrics(tstdata.y,NFinoutputU_21(expno).test.projection,K);
    [rFpTrU,rFnTrU,e4]=computeMetrics(trndata.y,NFinoutputU_21(expno).train.projection,K);
    
    fprintf('*************** DIGIT 60(EXPNO=%d) ***************\n',expno);
    fprintf('U SVM::Test data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTsU,rFnTsU);
    fprintf('U SVM::Train data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTrU,rFnTrU);
    

    
    [rFpTsU,rFnTsU,e3]=computeMetrics(tstdata.y,NFinoutputU_41(expno).test.projection,K);
    [rFpTrU,rFnTrU,e4]=computeMetrics(trndata.y,NFinoutputU_41(expno).train.projection,K);
    
    fprintf('*************** RA(EXPNO=%d) ***************\n',expno);
    fprintf('U SVM::Test data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTsU,rFnTsU);
    fprintf('U SVM::Train data----> Ratio of false positive=%d and Ratio of false negative= %d\n ',rFpTrU,rFnTrU);
    
    

    
end






function [out]=arrangeProjectionDisplay(projection,y)
    
    index1=find(y==1);
    index2=find(y==-1);
    nocls1=size(index1,1);
    nocls2=size(index2,1);
    dataProj=projection(index1);
    dataProj=[dataProj,projection(index2)];
    out.projection=dataProj;
    out.nocls1=nocls1;
    out.nocls2=nocls2;

    
function [rFp,rFn,error,nFp,nFn]=computeMetrics(y,projection,K)
y_est=sign(projection');
y_est(find(y_est==0))=1;
y_true=y;
nFn=length(find(y_est<y_true));
nFp=length(find(y_est>y_true));

n_plus=length(find(y_true>0));
n_minus=length(find(y_true<0));
error=(K*nFp+nFn)/(K*n_minus+n_plus);
rFp=nFp;
rFn=nFn;