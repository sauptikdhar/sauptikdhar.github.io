
function [RPred,RPredU,RPred_1,RPredU_1,Finmodel,FinmodelU,Finoutput,FinoutputU,optparam,Finmodel_1,FinmodelU_1,Finoutput_1,FinoutputU_1,optparam_1,trnv,valv,tstv,univ]=example3U_NSTD()
%--------------------------------------------------------------------------
% AUTHOR:- SAUPTIK DHAR
% DESCRIPTION:-
% [RPred,RPredNSTD,Finmodel,FinmodelNSTD,Finoutput,FinoutputNSTD,optparam,optparamNSTD]=example3NSTD()
% Experiment to compare between SVM vs N-STD SVM using hypercube data
%--------------------------------------------------------------------------

cleanData();

for expno=1:5
    % CREATE THE DATA FILES
    [trndata]=generateHypercubedata(1000,1000,200);
    [valdata]=generateHypercubedata(1000,1000,200);
    [tstdata]=generateHypercubedata(1000,1000,200);
    [univdata]=generateUnivSamp(trndata,1000,0.5);%
%    valdata=tstdata;
% trndata.X=rand(10,2);
% trndata.y=sign(randn(10,1));
% tstdata=trndata;
% valdata=trndata;
% [univdata]=generateUnivSamp(trndata,10,0.5);

    trnv(expno)=trndata;
    valv(expno)=valdata;
    tstv(expno)=tstdata;
    univ(expno)=univdata;
    
 
    
    param.cset=2.^[-8:-3];
    param.t='linear';
    param.K=0.1;
    param.k=1;
    K=param.K;
    param.N=0;
    %RUN EXPERIMENT
    param.Cset=[];param.Gset=[];
    [RPred(expno),RPredU(expno),Remp(expno),RempU(expno),Finmodel(expno),FinmodelU(expno),Finoutput(expno),FinoutputU(expno),optparam(expno)]=ExpwithValSet(trndata,valdata,tstdata,univdata,param);
    
    [train]=arrangeProjectionDisplay(Finoutput(expno).train.projection,trndata.y); 
    %DISPLAY
%     h=hist_of_output(train.projection,train.nocls1,train.nocls2);
%     set(h,'Name',['SVM (exp no ',num2str(expno),') Pred Risk(SVM)= ',num2str(RPred(expno)),'%']);  
    
    [nFpTs,nFnTs,e1]=computeMetrics(tstdata.y,Finoutput(expno).test.projection,K);
    [nFpTr,nFnTr,e2]=computeMetrics(trndata.y,Finoutput(expno).train.projection,K);

    fprintf('-------------------------------------------------------------\n');
    fprintf('\nExp no= %d, Pred Risk(SVM)=%f\n',expno,RPred(expno));
    fprintf('SVM::Test data----> No. of false positive=%d and No. of false negative= %d \n',nFpTs,nFnTs);
    fprintf('SVM::Train data----> No. of false positive=%d and No. of false negative= %d \n',nFpTr,nFnTr);
     
    
    param.K=0.1;
    param.k=0.1;
    K=param.K;
    param.N=1;
    param.Cset=2.^[-8:0];
    param.Gset=[0,0.01,0.1,0.2];
    %RUN EXPERIMENT
    [RPred_1(expno),RPredU_1(expno),Remp_1(expno),RempU_1(expno),Finmodel_1(expno),FinmodelU_1(expno),Finoutput_1(expno),FinoutputU_1(expno),optparam_1(expno)]=ExpwithValSet(trndata,valdata,tstdata,univdata,param);
    [train]=arrangeProjectionDisplay(Finoutput_1(expno).train.projection,trndata.y); 
    
    %DISPLAY
%     h=hist_of_output(train.projection,train.nocls1,train.nocls2);
%     set(h,'Name',['NSTD SVM (exp no ',num2str(expno),') Pred Risk(NSTD SVM)= ',num2str(RPred_1(expno)),'%']);  
    
    [nFpTs,nFnTs,e1]=computeMetrics(tstdata.y,Finoutput_1(expno).test.projection,K);
    [nFpTr,nFnTr,e2]=computeMetrics(trndata.y,Finoutput_1(expno).train.projection,K);
    
    
%     [train]=arrangeProjectionDisplay(FinoutputU_1(expno).train.projection,trndata.y); 
%     h=hist_of_output(train.projection,train.nocls1,train.nocls2);
%     set(h,'Name',['U SVM NSTD(no changes) (exp no ',num2str(expno),') Pred Risk(NSTD-USVM)= ',num2str(RPredU_1(expno)),'%']);  
    [nFpTsU,nFnTsU,e3]=computeMetrics(tstdata.y,FinoutputU_1(expno).test.projection,K);
    [nFpTrU,nFnTrU,e4]=computeMetrics(trndata.y,FinoutputU_1(expno).train.projection,K);
    
    fprintf('\n\nExp no= %d, Pred Risk(NSTD-SVM)=%f, Pred Risk(NSTD-USVM)=%f\n',expno,RPred_1(expno),RPredU_1(expno));
    %display(optparam_1(expno));
    fprintf('NSTD SVM::Test data----> No. of false positive=%d and No. of false negative= %d \n',nFpTs,nFnTs);
    fprintf('NSTD SVM::Train data----> No. of false positive=%d and No. of false negative= %d \n',nFpTr,nFnTr);
    display('N-USVM')
    fprintf('NSTD USVM::Test data----> No. of false positive=%d and No. of false negative= %d\n ',nFpTsU,nFnTsU);
    fprintf('NSTD USVM::Train data----> No. of false positive=%d and No. of false negative= %d\n ',nFpTrU,nFnTrU);
     
end


function [out]=arrangeProjectionDisplay(projection,y)
    
    index1=find(y==1);
    index2=find(y==-1);
    nocls1=size(index1,1);
    nocls2=size(index2,1);
    dataProj=projection(index1);
    dataProj=[dataProj,projection(index2)];
    out.projection=dataProj;
    out.nocls1=nocls1;
    out.nocls2=nocls2;

    
function [rFp,rFn,error,nFp,nFn]=computeMetrics(y,projection,K)
y_est=sign(projection');
y_est(find(y_est==0))=1;
y_true=y;
nFn=length(find(y_est<y_true));
nFp=length(find(y_est>y_true));

n_plus=length(find(y_true>0));
n_minus=length(find(y_true<0));
error=(K*nFp+nFn)/(K*n_minus+n_plus);
rFp=nFp;
rFn=nFn;