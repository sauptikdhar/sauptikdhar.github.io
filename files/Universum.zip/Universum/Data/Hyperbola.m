
function [data]=Hyperbola(nsamp,sigma)
%-------------------------------------------------------------------------
% AUTHOR:- WUYANG DAI
% DESCRIPTION:- 
% [data]=Hyperbola(trnnum,sigma)
% This interface is used to generate the Hyperbola Data.
% INPUT:-
%   nsamp:- Number of samples.(for each class)
%   sigma:- Noise level.
% OUTPUT:- 
%   data:- this is the o/p data with the reqd formats
%--------------------------------------------------------------------------
trnnum = nsamp; % the number of training samples in each class (positive or negative)
    
x1 = [0.2:0.4/(trnnum-1):0.6]';
y1 = sigma*randn(trnnum,1)+((x1-0.4)*3).^2+0.225;
x1 = x1 + sigma*randn(trnnum,1);
cls1data.X = [x1,y1];
cls1data.y = ones(size(cls1data.X,1),1);

x2 = [0.4:0.4/(trnnum-1):0.8]';
y2 = sigma*randn(trnnum,1)+1-((x2-0.6)*3).^2-0.225;
x2 = x2 + sigma*randn(trnnum,1);
cls2data.X = [x2,y2];
cls2data.y = -ones(size(cls2data.X,1),1);

trndata.X = [cls1data.X;cls2data.X];
trndata.y = [cls1data.y;cls2data.y];
data=trndata;


% figure;
% hold on;
% plot(cls1data.X(:,1),cls1data.X(:,2),'ro');
% plot(cls2data.X(:,1),cls2data.X(:,2),'bx');