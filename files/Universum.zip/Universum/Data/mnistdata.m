function [trndata,valdata,tstdata,udata]= mnistdata(class1,class2,uclass,ntrn,nval,ntst,usize)
%--------------------------------------------------------------------------
%AUTHOR:- SAUPTIK DHAR , WUYANG DAI
%DESCRIPTION:-
% This interface is used to load MNIST data as described in
% the paper 'Practical Conditions for Effectiveness of the Universum
% Learning'
%INPUT:
%   class1= This is the digit that is to be used with class label [+1]
%   class2= this is the digit that is to be used with class label [-1]
%   uclass= This is the digit that can be used as universum
%   samples.(optional).
%   ntrn= The no. of training samples per class.
%   ntst= No. of Test Samples per class.
%   usize= No. of Universum Samples.
%   
%OUTPUT:
%   trndata= This is the training mnist data.
%   valdata= This is the validation data.
%   tstdata= This is the Test data.
%   udata= This is the universum data.(A different digit.In case we do not do a RA)
% The data is publicly available at:-
% http://www.cs.toronto.edu/~roweis/data.html
%--------------------------------------------------------------------------




%INITIALIZE
trndata=struct;
valdata=struct;
tstdata=struct;
udata=struct;
trnsize=ntrn;
valsize=nval;
tstsize=ntst;


%PREPARE CLASS +1
[trnX,tstX]=getclassdata(class1);

if(isempty(ntrn))
    trnsize=size(trnX,1);
    valsize=0;
    partition=trnsize;
else partition=floor(size(trnX,1)/2);
end

if(isempty(ntst))
    tstsize=size(tstX,1);
end

trndata.X=generateData(trnX(1:partition,:),trnsize); % Be sure that Training data and Validation data are mutually exclusive
valdata.X=generateData(trnX(partition+1:end,:),valsize);
trndata.y=ones(trnsize,1);
valdata.y=ones(valsize,1);


tstdata.X=generateData(tstX,tstsize);
tstdata.y=ones(tstsize,1);

%PREPARE CLASS -1
[trnX,tstX]=getclassdata(class2);

if(isempty(ntrn))
    trnsize=size(trnX,1);
    valsize=0;
    partition=trnsize;
else partition=floor(size(trnX,1)/2);
end

if(isempty(ntst))
    tstsize=size(tstX,1);
end

trndata.X=[trndata.X;generateData(trnX(1:partition,:),trnsize)];
valdata.X=[valdata.X;generateData(trnX(partition+1:end,:),valsize)];
trndata.y=[trndata.y;-ones(trnsize,1)];
valdata.y=[valdata.y;-ones(valsize,1)];


tstdata.X=[tstdata.X;generateData(tstX,tstsize)];
tstdata.y=[tstdata.y;-ones(tstsize,1)];


% PREPARE U SAMPLES
if(~isempty(uclass))
    [trnX,tstX]=getclassdata(uclass);
    uclassX=[trnX;tstX];
    udata.X=generateData(uclassX,usize);
    udata.y=-2*ones(size(udata.X,1),1);
end





function dataX=generateData(dataX,dsize)
% This will randomly select the samples and construct a dataset from dataX
% as the same size of dsize.dsize cannot exceed size(dataX,1)
[M]=size(dataX,1);
[index]=randperm(M);
if(isempty(dsize))
    dsize=M;
end
[selectindex]=index(1:dsize);
dataX=dataX(selectindex,:);


function [trnX,tstX]=getclassdata(digit)
% This will return the class data
load mnist_all;
switch(digit)
    case 1,trnX=im2double(train1);tstX=im2double(test1);
    case 2,trnX=im2double(train2);tstX=im2double(test2);
    case 3,trnX=im2double(train3);tstX=im2double(test3);
    case 4,trnX=im2double(train4);tstX=im2double(test4);
    case 5,trnX=im2double(train5);tstX=im2double(test5);
    case 6,trnX=im2double(train6);tstX=im2double(test6);
    case 7,trnX=im2double(train7);tstX=im2double(test7);
    case 8,trnX=im2double(train8);tstX=im2double(test8);
    case 9,trnX=im2double(train9);tstX=im2double(test9);
    case 0,trnX=im2double(train0);tstX=im2double(test0);
    otherwise, error('The digit entered is wrong!');
end

