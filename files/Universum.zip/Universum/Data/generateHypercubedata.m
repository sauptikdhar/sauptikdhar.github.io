function [data]=generateHypercubedata(nsamp,dim,effVar)
%--------------------------------------------------------------------------
%AUTHOR:- SAUPTIK DHAR
%DESCRIPTION:-
% This interface is used to generate the Hypercube dataset as described in
% the paper 'Practical Conditions for Effectiveness of the Universum
% Learning''
%INPUT:
%   nsamp= This is the number of samples to be generated.
%   dim=   This is the dimension of the samples. 
%   effVar= This specifies the number of variables effectivly used in the
%   decision function!
%OUTPUT:
%   data= This is the hypercube data.
%Note:- The number of samples for each classes will be equal
%--------------------------------------------------------------------------

data.X=rand(nsamp,dim);
data.y=sign(sum(data.X(:,1:effVar),2)-100);
