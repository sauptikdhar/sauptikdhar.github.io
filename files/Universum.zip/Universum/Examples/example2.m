
function [RPred,RPredU,Finmodel,FinmodelU,Finoutput,FinoutputU,optparam]=example2(noise)
%--------------------------------------------------------------------------
% AUTHOR:- SAUPTIK DHAR
% DESCRIPTION:-
% [RPred,RPredU,Finmodel,FinmodelU,Finoutput,FinoutputU,optparam]=example3()
% This example is developed the show the experimental results given in Table 3 
%'Practical Conditions for Effectiveness of the Universum
% Learning'.
% In this setup we use the High Dimensional Hypercube data.
%--------------------------------------------------------------------------

cleanData();

for expno=1:10
    % CREATE THE DATA FILES
    [trndata]=Hyperbola(50,noise);
    [valdata]=Hyperbola(50,noise);
    [tstdata]=Hyperbola(1000,noise);
    [univdata]=generateUnivSamp(trndata,1000,0.5);
   
    % DEFINE THE PARAMETERS
    param.cset=[0.01, 0.1, 1, 10, 100, 1000];
    param.gset=[2^-8,2^-6,2^-4,2^-2,1,2^2,2^4];
    param.Cset=[0.01,0.03,0.1,0.3,1,3,10];
    param.Gset=[0,0.02,0.05,0.1,0.2];
    param.t='rbf';
    
    %RUN EXPERIMENT
    [RPred(expno),RPredU(expno),junk1,junk2,Finmodel(expno),FinmodelU(expno),Finoutput(expno),FinoutputU(expno),optparam(expno)]=ExpwithValSet(trndata,valdata,tstdata,univdata,param);
     
    %DISPLAY
    [dataProjunivproj]=getUnivProj(Finmodel(expno),univdata);
    h=hist_of_output_with_univ(Finoutput(expno).train.projection,dataProjunivproj,Finoutput(expno).train.nocls1,Finoutput(expno).train.nocls2);
    set(h,'Name',['STANDARD SVM with (UNIVERSUM samples) (exp no ',num2str(expno),') Pred Risk(SVM)= ',num2str(RPred(expno)),'%','Pred Risk(USVM)= ',num2str(RPredU(expno))]);  
    fprintf('Exp no= %d, Pred Risk(SVM)=%f, Pred Risk(USVM)=%f \n Optimal C= %f\n Optimal C*=%f\nOptimal Epsilon=%f\n',expno,RPred(expno),RPredU(expno),optparam(expno).c,optparam(expno).C,optparam(expno).G);
end