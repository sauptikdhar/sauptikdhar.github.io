
function [RPred,RPredU_1,RPredU_3,RPredU_6,optparam_1,optparam_3,optparam_6]=example6()
%--------------------------------------------------------------------------
% AUTHOR:- SAUPTIK DHAR
% DESCRIPTION:-
%[RPred,RPredU_1,RPredU_3,RPredU_6,optparam_1,optparam_3,optparam_6]=example6()
% This example is developed the show the experimental results given in Table 6 
%'Practical Conditions for Effectiveness of the Universum
% Learning'.
% In this setup we use the MNIST data.
%--------------------------------------------------------------------------

cleanData();

for expno=1:10
    % CREATE THE DATA FILES
    [trndata,valdata,tstdata,udata_1]= mnistdata(5,8,1,500,500,[],1000); 
    [trndata,valdata,tstdata,udata_3]= mnistdata(5,8,3,500,500,[],1000);
    [trndata,valdata,tstdata,udata_6]= mnistdata(5,8,6,500,500,[],1000);

    % DEFINE THE PARAMETERS
    param.cset=[0.01, 0.1, 1, 10, 100, 1000];
    param.gset=[2^-8,2^-6,2^-4,2^-2,1,2^2,2^4];
    param.Cset=[0.01,0.03,0.1,0.3,1,3,10];
    param.Gset=[0,0.02,0.05,0.1,0.2];
    param.t='rbf';
    
    %RUN EXPERIMENT
    [RPred(expno),RPredU_1(expno),junkA,junkB,Finmodel(expno),FinmodelU_1(expno),Finoutput(expno),FinoutputU_1(expno),optparam_1(expno)]=ExpwithValSet(trndata,valdata,tstdata,udata_1,param);
    param.cset=[];
    param.c=optparam_1(expno).c;
    param.g=optparam_1(expno).g;
    [junk1(expno),RPredU_3(expno),junkA,junkB,junk2(expno),FinmodelU_3(expno),junk3(expno),FinoutputU_3(expno),optparam_3(expno)]=ExpwithValSet(trndata,valdata,tstdata,udata_3,param);
    [junk1(expno),RPredU_6(expno),junkA,junkB,junk2(expno),FinmodelU_6(expno),junk3(expno),FinoutputU_6(expno),optparam_6(expno)]=ExpwithValSet(trndata,valdata,tstdata,udata_6,param);
    
    %DISPLAY
    [dataProjunivproj]=getUnivProj(Finmodel(expno),udata_1);
    h=hist_of_output_with_univ(Finoutput(expno).train.projection,dataProjunivproj,Finoutput(expno).train.nocls1,Finoutput(expno).train.nocls2);
    set(h,'Name',['STANDARD SVM with (digit 1) (exp no ',num2str(expno),') Pred Risk(SVM)= ',num2str(RPred(expno)),'%','Pred Risk(USVM)= ',num2str(RPredU_1(expno))]);
    fprintf('Exp no= %d, Pred Risk(SVM)=%f, Pred Risk(USVM)=%f \n Optimal C= %f\n Optimal C*=%f\nOptimal g(radius)=%f\n Optimal Epsilon=%f\n',expno,RPred(expno),RPredU_1(expno),optparam_1(expno).c,optparam_1(expno).C,optparam_1(expno).g,optparam_1(expno).G);
    
     [dataProjunivproj]=getUnivProj(Finmodel(expno),udata_3);
     h=hist_of_output_with_univ(Finoutput(expno).train.projection,dataProjunivproj,Finoutput(expno).train.nocls1,Finoutput(expno).train.nocls2);
     set(h,'Name',['STANDARD SVM with (digit 3) (exp no ',num2str(expno),') Pred Risk(SVM)= ',num2str(RPred(expno)),'%','Pred Risk(USVM)= ',num2str(RPredU_3(expno))]);
     fprintf('Exp no= %d, Pred Risk(SVM)=%f, Pred Risk(USVM)=%f \n Optimal C= %f\n Optimal C*=%f\nOptimal g(radius)=%f\n Optimal Epsilon=%f\n',expno,RPred(expno),RPredU_3(expno),optparam_3(expno).c,optparam_3(expno).C,optparam_3(expno).g,optparam_3(expno).G);
     
     [dataProjunivproj]=getUnivProj(Finmodel(expno),udata_6);
     h=hist_of_output_with_univ(Finoutput(expno).train.projection,dataProjunivproj,Finoutput(expno).train.nocls1,Finoutput(expno).train.nocls2);
     set(h,'Name',['STANDARD SVM with (digit 6) (exp no ',num2str(expno),') Pred Risk(SVM)= ',num2str(RPred(expno)),'%','Pred Risk(USVM)= ',num2str(RPredU_6(expno))]);
     fprintf('Exp no= %d, Pred Risk(SVM)=%f, Pred Risk(USVM)=%f \n Optimal C= %f\n Optimal C*=%f\nOptimal g(radius)=%f\n Optimal Epsilon=%f\n',expno,RPred(expno),RPredU_6(expno),optparam_6(expno).c,optparam_6(expno).C,optparam_6(expno).g,optparam_6(expno).G);
end