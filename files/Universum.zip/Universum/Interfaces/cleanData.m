function cleanData()
%--------------------------------------------------------------------------
% AUTHOR:- SAUPTIK DHAR
% DESCRIPTION:-
% cleanData()
%
% This is a interface that will delete all the available files in the folder
% (/Engine/Data).
% INPUT:-
%   None
% OUTPUT:-
%   None
%--------------------------------------------------------------------------

delete('*.dat');
delete('*.mdl');
delete('*.out');