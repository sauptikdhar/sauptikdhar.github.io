function [data]=loadFile(filename)
%--------------------------------------------------------------------------
% AUTHOR:- SAUPTIK DHAR
% DESCRIPTION:-
% [data,success]=loadFile(filename,folder)
%
% This interface will load the file that is specified by the filename.By
% default it will only search in the folder (/Engine/Data)
%
% INPUT:-
%   filename:- This specifies the name of the file in which the data has
%   been stored.
% OUTPUT:-
%   data: - This is the data that is available in the file specified by the
%   filename.This file has to be present in the folder (/Engine/Data)
%--------------------------------------------------------------------------

