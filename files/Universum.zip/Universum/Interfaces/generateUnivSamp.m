function [univdata]=generateUnivSamp(trndata,usize,weight)
%--------------------------------------------------------------------------
% AUTHOR:- SAUPTIK DHAR
% DESCRIPTION:-
%   [trnunivdata]=generateUnivSamp(trndata,usize)
% This interface is used to generate the universum samples from training
% data using  weighted random averaging.
% INPUT:-
%   trndata:- This is the training data.This is a structure with the
%   following fields
%        trndata.X= the X values for the training data.
%        trndata.y= The y labels for the training data [+1,-1]
%   usize:- the number of Universum samples to be generated.(default 100)
%   weight:-this is an optional parameter that specifies the weight to be
%   given to the samples of class +1.(default weight=0.5)
% OUTPUT:-
%   trnunivdata:- This is the training data along with the universum
%   samples.This is a structure with the following parameters.
%       trnunivdata.X= this is the X values for the data.
%       trnunivdata.y= this is the label for the data.For universum samples
%       this value is -2.
%--------------------------------------------------------------------------
 switch(nargin)
     case 1, usize=100;weight=0.5;
     case 2, weight=0.5;
     case 3;
     otherwise, error('The number of parameters specified is wrong!');
 end



allindclass1=find(trndata.y==1);
allindclass2=find(trndata.y==-1);

nsampclass1=size(allindclass1,1);
nsampclass2=size(allindclass2,1);

randindclass1=allindclass1(randint(1,usize,nsampclass1)+1,1);
randindclass2=allindclass2(randint(1,usize,nsampclass2)+1,1);

udataX=weight.*trndata.X(randindclass1,:)+(1-weight).*trndata.X(randindclass2,:);
udatay=-2*ones(size(udataX,1),1);


univdata.X=udataX;
univdata.y=udatay;
