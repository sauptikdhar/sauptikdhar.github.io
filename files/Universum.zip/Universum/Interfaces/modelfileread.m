function [model] = modelfileread(modelfile,dim)
%--------------------------------------------------------------------------
% AUTHOR:- WUYANG DAI
% DESCRIPTION:
%   [model] = modelfileread(modelfile,dim)
% This function reads the output model file from Universvm present it in a
% readable format.
% INPUT:-
%   modelfile:- This is the modelfile name.This file should have a .mdl
%   extension
%   dim:-  This is the dimension of the input data.
% OUTPUT:-
%   model:- This is the SVM model in a readable format.This is a structure
%   with the following fields.
%       model.alpha= These are the alpha values.The dimension is [nsv*1].
%       model.sv.X= These are the X values of the support vectors.This has
%       a dimension of [dim*nsv].
%       model.b0= This is the bias of the model.(decision function)
%       model.nsv= This is the number of support vectors.
%--------------------------------------------------------------------------
format long;
fid = fopen(modelfile);
line = fgetl(fid);
alpha = [];
% the first line is about the b0 value
if ischar(line)
    index = strfind(line,'b0 ');
    if isempty(index)
    else
        line = line(index+3:end);
        b0 = sscanf(line,'%f');
    end
end

% the second line is about the kernel type
line = fgetl(fid);
if ischar(line)
    index = strfind(line,'kernel_type ');
    if isempty(index)
    else
        line = line(index+12:end);
        ktype = sscanf(line,'%c');
    end
end

line = fgetl(fid);
while (ischar(line))
    index = strfind(line,'total_sv ');
    if isempty(index)
        
    else
        line = line(index+9:end);
        nsv = sscanf(line,'%f');
        if nargin >= 2
            svx = zeros(dim,nsv);
        end
        line = fgetl(fid);
        for i = 1:nsv
            line = fgetl(fid);
            [alpha(i),count,errmsg,index] = sscanf(line,'%f',1);
            line = line(index+1:end);
%             index = strfind(line,':');
%             for j = 1:length(index)
%                 sline = line(index(j)+1:end);
%                 svx(j,i) = sscanf(sline,'%f',1);
%                 %each column of svx is one data sample
%             end
            while(~isempty(line))
                [nrow,count,errmsg,index] = sscanf(line,'%f',1);
                line = line(index+1:end);
                [elem,count,errmsg,index] = sscanf(line,'%f',1);
                line = line(index+1:end);
                svx(nrow,i) = elem;
            end
        end
    end
    line = fgetl(fid);
end
fclose(fid);

model.b = b0;
model.Alpha = alpha';
model.sv.X = svx;
model.options.ker = ktype;
model.options.arg = 1; % default value of STPRtool
model.nsv = nsv;
format short;