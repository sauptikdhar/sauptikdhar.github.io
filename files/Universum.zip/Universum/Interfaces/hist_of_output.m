function h=hist_of_output(output,N_cls1,N_cls2)
%--------------------------------------------------------------------------
% AUTHOR: WUYANG DAI
% DESCRIPTION: 
%   h=hist_of_dataProj_with_univ(dataProj,dataProjuniv,N_cls1,N_cls2)
% This interface is used to plot he projection diagram.
% INPUT:-
%   dataProj= This is the projection data for training data.
%   dataProjuniv= This is the projection data for universum samples.
%   N_cls1 =is the number of samples of class 1[+1]
%   N_cls2 =is the number of samples of class 2[-1]
% dataProj:-
%   h= Handler for the figure.
%--------------------------------------------------------------------------

cls1proj = output(1:N_cls1);
cls2proj = output(N_cls1+1:N_cls1+N_cls2);

[stat1,x1] = hist(cls1proj);
[stat2,x2] = hist(cls2proj);

h=figure;
hold on;
mid_height = (max([stat1,stat2]) + min([stat1,stat2]))/2;
cls1h = mid_height*ones(size(cls1proj,1),size(cls1proj,2));
cls2h = mid_height*ones(size(cls2proj,1),size(cls2proj,2));
plot(cls1proj,cls1h,'bo');
plot(cls2proj,cls2h,'r+');

plot(x1,stat1,'b');
plot(x2,stat2,'r');
plot([0,0],[0,max([stat1,stat2])],'k');
plot([-1,-1],[0,max([stat1,stat2])],'k-.');
plot([+1,+1],[0,max([stat1,stat2])],'k-.');
